<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Image Slider', 'kerge-shortcodes' ),
	'description' => esc_html__( 'Add Image Slider', 'kerge-shortcodes' ),
	'tab'         => esc_html__( 'Kerge Media Elements', 'kerge-shortcodes' ),
);