<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Quote', 'kerge-shortcodes' ),
		'description' => esc_html__( 'Add a Quote', 'kerge-shortcodes' ),
		'tab'         => esc_html__( 'Kerge Elements', 'kerge-shortcodes' ),
		'popup_size'  => 'medium'
	)
);